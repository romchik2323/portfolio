import pandas as pd
import numpy as np

np.random.seed(42)

products = ['Телефон', 'Ноутбук', 'Планшет', 'Наушники', 'Часы']
dates = pd.date_range('2024-01-01', '2024-03-31', freq='D')

data = {
    'Дата': np.random.choice(dates, 200),
    'Товар': np.random.choice(products, 200),
    'Количество продаж': np.random.randint(1, 20, 200),
    'Выручка': np.random.uniform(1000, 50000, 200).round(2)
}

df = pd.DataFrame(data)
df.to_csv('sales_data.csv', index=False)
print('sales_data.csv успешно создан.')