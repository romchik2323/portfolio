
import matplotlib
matplotlib.use('Agg')  
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  
import pandas as pd
from io import BytesIO
import base64

def matplotlib_chart(df, chart_type, selected_product, start_date, end_date):
    filtered_df = df.copy()
    
   
    if selected_product != "Все":
        filtered_df = filtered_df[filtered_df['Товар'] == selected_product]
    filtered_df = filtered_df[(filtered_df['Дата'] >= start_date) & 
                            (filtered_df['Дата'] <= end_date)]

    
    if filtered_df.empty:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.text(0.5, 0.5, 'Нет данных', ha='center', va='center')
        ax.set_title("Ошибка: Нет данных")
    else:
        if chart_type == "3D Scatter":
            fig = plt.figure(figsize=(10, 8))
            ax = fig.add_subplot(111, projection='3d')
            
            
            dates = pd.to_datetime(filtered_df['Дата']).astype('int64') // 10**9
            products = filtered_df['Товар'].astype('category').cat.codes
            
            
            scatter = ax.scatter(
                dates,
                products,
                filtered_df['Количество продаж'],
                c=filtered_df['Выручка'],
                cmap='viridis',
                s=50
            )
            
            
            ax.set_xlabel('Дата (Unix Time)')
            ax.set_ylabel('Товар')
            ax.set_zlabel('Продажи')
            ax.set_title('3D Scatter: Дата, Товар, Продажи')
            
            
            unique_products = filtered_df['Товар'].unique()
            ax.set_yticks(range(len(unique_products)))
            ax.set_yticklabels(unique_products)
            
            
            plt.colorbar(scatter, label='Выручка')

        

        elif chart_type == "Столбчатая диаграмма":
            fig, ax = plt.subplots(figsize=(8, 6))
            filtered_df.groupby('Товар')['Количество продаж'].sum().plot(kind='bar', ax=ax)
            ax.set_title('Продажи по товарам')

        elif chart_type == "Линейный график":
            fig, ax = plt.subplots(figsize=(8, 6))
            df_grouped = filtered_df.groupby('Дата').sum(numeric_only=True)
            df_grouped['Количество продаж'].plot(kind='line', ax=ax)
            ax.set_title('Продажи по датам')

        elif chart_type == "Круговая диаграмма":
            fig, ax = plt.subplots(figsize=(8, 6))
            df_grouped = filtered_df.groupby('Товар').sum(numeric_only=True)
            df_grouped['Выручка'].plot(kind='pie', ax=ax, autopct='%1.1f%%')
            ax.set_ylabel('')
            ax.set_title('Доля товаров в выручке')

        elif chart_type == "Диаграмма рассеяния":
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.scatter(filtered_df['Количество продаж'], filtered_df['Выручка'], c='blue', s=30)
            ax.set_xlabel('Количество продаж')
            ax.set_ylabel('Выручка')
            ax.set_title('Связь продаж и выручки')

    
    buf = BytesIO()
    plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
    buf.seek(0)
    img_base64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    
    return img_base64