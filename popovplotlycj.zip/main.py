
import sys
import pandas as pd
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QVBoxLayout, 
    QWidget, QComboBox, QLabel, QDateEdit, QHBoxLayout
)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QDate
from plotly_viewer import plotly_chart
from matplotlib_viewer import matplotlib_chart


app = QApplication(sys.argv)
window = QMainWindow()
window.setWindowTitle('Визуализация продаж')


df = pd.read_csv('sales_data.csv')
df['Дата'] = pd.to_datetime(df['Дата'])


central_widget = QWidget()
window.setCentralWidget(central_widget)
layout = QVBoxLayout()
central_widget.setLayout(layout)


top_layout = QHBoxLayout()

chart_type = QComboBox()
chart_type.addItems(["Столбчатая диаграмма", "Линейный график", "Круговая диаграмма", "Диаграмма рассеяния","3D Scatter"])
top_layout.addWidget(QLabel("Тип графика:"))
top_layout.addWidget(chart_type)

product_filter = QComboBox()
product_filter.addItems(["Все"] + list(df['Товар'].unique()))
top_layout.addWidget(QLabel("Товар:"))
top_layout.addWidget(product_filter)

start_date = QDateEdit()
start_date.setDate(QDate(2024, 1, 1))
top_layout.addWidget(QLabel("От:"))
top_layout.addWidget(start_date)

end_date = QDateEdit()
end_date.setDate(QDate(2024, 3, 31))
top_layout.addWidget(QLabel("До:"))
top_layout.addWidget(end_date)

library_choice = QComboBox()
library_choice.addItems(["Plotly", "Matplotlib"])
top_layout.addWidget(QLabel("Библиотека:"))
top_layout.addWidget(library_choice)

update_button = QPushButton("Построить график")
top_layout.addWidget(update_button)

layout.addLayout(top_layout)


graph_view = QWebEngineView()
layout.addWidget(graph_view)


def update_chart():
    chart = chart_type.currentText()
    product = product_filter.currentText()
    start = pd.Timestamp(start_date.date().toPyDate())
    end = pd.Timestamp(end_date.date().toPyDate())
    library = library_choice.currentText()

    if library == "Plotly":
        fig = plotly_chart(df, chart, product, start, end)
        html = fig.to_html(include_plotlyjs='cdn') if fig else "<h1>Нет данных</h1>"
    else:
        img_base64 = matplotlib_chart(df, chart, product, start, end)
        html = f'<img src="data:image/png;base64,{img_base64}">'

    graph_view.setHtml(html)

update_button.clicked.connect(update_chart)
update_chart()  


window.show()
sys.exit(app.exec())