
import plotly.express as px
import pandas as pd

def plotly_chart(df, chart_type, selected_product, start_date, end_date):
    filtered_df = df.copy()
    
    if selected_product != "Все":
        filtered_df = filtered_df[filtered_df['Товар'] == selected_product]
    filtered_df = filtered_df[(filtered_df['Дата'] >= start_date) & (filtered_df['Дата'] <= end_date)]

    if filtered_df.empty:
        return px.scatter(title="Нет данных для отображения")

    if chart_type == "Столбчатая диаграмма":
        fig = px.bar(filtered_df, x="Товар", y="Количество продаж", title="Продажи по товарам")
    elif chart_type == "Линейный график":
        df_grouped = filtered_df.groupby('Дата').sum(numeric_only=True).reset_index()
        fig = px.line(df_grouped, x="Дата", y="Количество продаж", title="Продажи по датам")
    elif chart_type == "Круговая диаграмма":
        df_grouped = filtered_df.groupby('Товар').sum(numeric_only=True).reset_index()
        fig = px.pie(df_grouped, names="Товар", values="Выручка", title="Доля товаров в выручке")
    elif chart_type == "Диаграмма рассеяния":
        fig = px.scatter(filtered_df, x="Количество продаж", y="Выручка", color="Товар", title="Связь продаж и выручки")
    elif chart_type == "3D Scatter":
        fig = px.scatter_3d(
            filtered_df, 
            x='Дата', 
            y='Товар', 
            z='Количество продаж',
            color='Выручка',
            title='3D Scatter: Дата, Товар, Продажи'
        )
    elif chart_type == "3D Surface":
        df_grouped = filtered_df.groupby(['Дата', 'Товар']).sum(numeric_only=True).reset_index()
        fig = px.density_heatmap(
            df_grouped, 
            x='Дата', 
            y='Товар', 
            z='Выручка',
            title='3D Surface: Выручка по датам и товарам'
        )
    else:
        fig = None

    return fig