#include "modeselectiondialog.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QMessageBox>

ModeSelectionDialog::ModeSelectionDialog(QWidget *parent)
    : QDialog(parent), selectedMode("") {

    setWindowTitle("Выбор режима работы");

    auto *layout = new QVBoxLayout(this);
    auto *label = new QLabel("Выберите режим работы:", this);
    layout->addWidget(label);

    basicModeButton = new QPushButton("Базовый", this);
    advancedModeButton = new QPushButton("Продвинутый", this);
    auto *cancelButton = new QPushButton("Отмена", this);

    layout->addWidget(basicModeButton);
    layout->addWidget(advancedModeButton);
    layout->addWidget(cancelButton);

    connect(basicModeButton, &QPushButton::clicked, this, &ModeSelectionDialog::onBasicModeSelected);
    connect(advancedModeButton, &QPushButton::clicked, this, &ModeSelectionDialog::onAdvancedModeSelected);
    connect(cancelButton, &QPushButton::clicked, this, &QDialog::reject);
}

QString ModeSelectionDialog::getSelectedMode() const {
    return selectedMode;
}

void ModeSelectionDialog::onBasicModeSelected() {
    selectedMode = "Базовый";
    accept();
}

void ModeSelectionDialog::onAdvancedModeSelected() {
    selectedMode = "Продвинутый";
    accept();
}
