#ifndef USER_H
#define USER_H

#include <QString>
#include <QSet>
#include <QMessageBox>
#include <QInputDialog>
#include <QRegularExpression>

class User {
public:
    User();
    void requestUserName(QWidget* parent);

private:
    QString userName;
    QSet<QString> existingNames;
};

#endif // USER_H
