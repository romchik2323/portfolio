#include "user.h"
#include <QLineEdit>

User::User() : userName(""), existingNames() {}

void User::requestUserName(QWidget* parent) {
    bool ok;
    QString name;

    do {
        name = QInputDialog::getText(parent, "Ввод имени пользователя",
                                     "Введите ваше имя:",
                                     QLineEdit::Normal, "", &ok);

        if (!ok) {
            // Закрываем родительское окно, если пользователь отменил ввод
            parent->close();
            return;
        }

        if (name.isEmpty()) {
            QMessageBox::warning(parent, "Ошибка", "Имя не может быть пустым!");
        } else if (name.contains(QRegularExpression("[^a-zA-Zа-яА-Я0-9_ ]"))) {
            QMessageBox::warning(parent, "Ошибка", "Имя содержит недопустимые символы!");
        } else if (existingNames.contains(name)) {
            QMessageBox::warning(parent, "Ошибка", "Это имя уже используется!");
        } else {
            userName = name;
            existingNames.insert(name);
            QMessageBox::information(parent, "Приветствие", "Добро пожаловать, " + userName + "!");
            break;
        }
    } while (true);
}
