#ifndef USERINPUTDIALOG_H
#define USERINPUTDIALOG_H

#include <QObject>
#include <QString>
#include <QSet>

class UserInputDialog : public QObject {
    Q_OBJECT

public:
    explicit UserInputDialog(QObject *parent = nullptr);
    QString getUserName(const QSet<QString> &existingNames, QWidget *parent);

private:
    QString validateUserName(const QString &name, const QSet<QString> &existingNames);

signals:
    void userCanceled(); // Сигнал для уведомления о том, что пользователь отменил ввод
};

#endif // USERINPUTDIALOG_H
