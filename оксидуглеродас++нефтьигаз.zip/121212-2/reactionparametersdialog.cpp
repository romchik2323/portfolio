#include "reactionparametersdialog.h"
#include <QFormLayout>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <QVBoxLayout>

ReactionParametersDialog::ReactionParametersDialog(QWidget *parent)
    : QDialog(parent), tempInput(new QLineEdit(this)), pressureInput(new QLineEdit(this)) {
    setWindowTitle("Параметры реакции");

    // Создаем форму ввода
    QFormLayout *formLayout = new QFormLayout;
    formLayout->addRow("Температура (T):", tempInput);
    formLayout->addRow("Давление:", pressureInput);

    // Кнопки "ОК" и "Отмена"
    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

    // Общий макет
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addLayout(formLayout);
    layout->addWidget(buttonBox);

    setLayout(layout);
}

ReactionParametersDialog::~ReactionParametersDialog() = default;

double ReactionParametersDialog::getTemperature() const {
    return tempInput->text().toDouble();
}

double ReactionParametersDialog::getPressure() const {
    return pressureInput->text().toDouble();
}
