#include "selectmodedialog.h"
#include <QInputDialog>

SelectModeDialog::SelectModeDialog(QWidget *parent)
    : QDialog(parent) {
    QStringList modes = {"Обычный", "Продвинутый"};
    bool ok;
    selectedMode = QInputDialog::getItem(this, "Выбор режима работы",
                                         "Выберите режим:", modes, 0, false, &ok);

    if (!ok || selectedMode.isEmpty()) {
        reject();
    } else {
        accept();
    }
}

QString SelectModeDialog::getSelectedMode() const {
    return selectedMode;
}
