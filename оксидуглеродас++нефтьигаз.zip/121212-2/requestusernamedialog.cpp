#include "requestusernamedialog.h"
#include <QInputDialog>
#include <QMessageBox>
#include <QRegularExpression>

RequestUserNameDialog::RequestUserNameDialog(QWidget *parent, QSet<QString> &existingNames)
    : QDialog(parent), existingNames(existingNames) {
    bool ok;
    do {
        userName = QInputDialog::getText(this, "Введите имя пользователя",
                                         "Введите ваше имя:", QLineEdit::Normal, "", &ok);

        if (!ok) {
            reject();
            return;
        }

        if (userName.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Имя не может быть пустым!");
        } else if (userName.contains(QRegularExpression("[^a-zA-Zа-яА-Я0-9_ ]"))) {
            QMessageBox::warning(this, "Ошибка", "Имя содержит недопустимые символы!");
        } else if (existingNames.contains(userName)) {
            QMessageBox::warning(this, "Ошибка", "Это имя уже используется!");
        } else {
            existingNames.insert(userName);
            accept();
            return;
        }
    } while (true);
}

QString RequestUserNameDialog::getUserName() const {
    return userName;
}
