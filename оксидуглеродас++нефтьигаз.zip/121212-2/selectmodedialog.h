#ifndef SELECTMODEDIALOG_H
#define SELECTMODEDIALOG_H

#include <QDialog>
#include <QString>

class SelectModeDialog : public QDialog {
    Q_OBJECT

public:
    explicit SelectModeDialog(QWidget *parent = nullptr);
    QString getSelectedMode() const;

private:
    QString selectedMode;
};

#endif // SELECTMODEDIALOG_H
