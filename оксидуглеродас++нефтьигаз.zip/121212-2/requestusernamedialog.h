#ifndef REQUESTUSERNAMEDIALOG_H
#define REQUESTUSERNAMEDIALOG_H

#include <QDialog>
#include <QSet>
#include <QString>

class RequestUserNameDialog : public QDialog {
    Q_OBJECT

public:
    explicit RequestUserNameDialog(QWidget *parent, QSet<QString> &existingNames);
    QString getUserName() const;

private:
    QString userName;
    QSet<QString> &existingNames;
};

#endif // REQUESTUSERNAMEDIALOG_H
