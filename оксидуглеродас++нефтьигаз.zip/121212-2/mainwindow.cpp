#include "mainwindow.h"
#include <QtWidgets/qdialog.h>

// Конструктор
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), userInputDialog(new UserInputDialog(this)) {
    requestUserName();
    selectMode();
    setupScene();
}

// Деструктор
MainWindow::~MainWindow() {
    delete userInputDialog;
    delete moleculeTimer;
    delete settlingTimer;
    delete cloudTimer;
    delete scene;
}


// Инициализация сцены
void MainWindow::setupScene() {
    scene = new QGraphicsScene(this);
    auto *view = new QGraphicsView(scene, this);
    view->setFixedSize(800, 600);
    scene->setSceneRect(0, 0, 800, 600);
    setCentralWidget(view);

    drawBackground();

    // Облака
    for (int i = 0; i < 5; ++i) {
        int x = QRandomGenerator::global()->bounded(0, 800);
        int y = QRandomGenerator::global()->bounded(20, 100);
        QGraphicsEllipseItem *cloud = scene->addEllipse(x, y, 100, 50, QPen(Qt::NoPen), QBrush(Qt::white));
        clouds.append(cloud);
    }

    // Резервуар
    reservoir = scene->addRect(300, 100, 200, 400, QPen(Qt::black), QBrush(Qt::lightGray));

    // Кран
    QBrush valveBrush(Qt::darkGray);
    valveBase = scene->addRect(50, 480, 40, 20, QPen(Qt::black), valveBrush);
    valveHandle = scene->addRect(60, 460, 20, 20, QPen(Qt::black), valveBrush);
    valveHandleTop = scene->addRect(50, 450, 40, 10, QPen(Qt::black), Qt::red);
    pipe = scene->addRect(90, 480, 210, 10, QPen(Qt::black), QBrush(Qt::darkGray));

    // Катализатор
    catalyst = scene->addRect(500, 200, 40, 200, QPen(Qt::black), QBrush(Qt::blue));

    // Таймеры
    moleculeTimer = new QTimer(this);
    connect(moleculeTimer, &QTimer::timeout, this, &MainWindow::updateMolecules);
    moleculeTimer->start(50);

    cloudTimer = new QTimer(this);
    connect(cloudTimer, &QTimer::timeout, this, &MainWindow::animateClouds);
    cloudTimer->start(100);

    settlingTimer = new QTimer(this);
    connect(settlingTimer, &QTimer::timeout, this, &MainWindow::animateSettling);
}

// Запрос имени пользователя
void MainWindow::requestUserName() {
    connect(userInputDialog, &UserInputDialog::userCanceled, this, &MainWindow::close);

    QString name = userInputDialog->getUserName(existingNames, this);
    if (name.isEmpty()) {
        return; // Пользователь отменил ввод
    }

    userName = name;
    existingNames.insert(userName);
    QMessageBox::information(this, "Приветствие", "Добро пожаловать, " + userName + "!");
}

// Выбор режима
void MainWindow::selectMode() {
    ModeSelectionDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        selectedMode = dialog.getSelectedMode();

        if (selectedMode == "Базовый") {
            QMessageBox::information(this, "Режим", "Каталитическая конверсия оксида углерода.");
        } else if (selectedMode == "Продвинутый") {
            enterReactionParameters();
        }
    } else {
        close(); // Закрываем приложение, если пользователь отменил выбор
    }
}

void MainWindow::enterReactionParameters() {
    ReactionParametersDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        double T = dialog.getTemperature();
        double P = dialog.getPressure();

        double deltaH = 9420 + 3.16 * T - 8.314 * pow(10, -3) * pow(T, 2) + 5.17 * pow(10, -6) * pow(T, 3) - 1.131 * pow(10, -9) * pow(T, 4);
        double logKp = -2.4198 + 0.0003855 * T + 2180.6 / T;

        QString result = QString("Температура (T): %1\n"
                                 "Давление (P): %2\n"
                                 "Тепловой эффект (ΔH): %3\n"
                                 "Константа равновесия (Kp): %4")
                             .arg(T)
                             .arg(P)
                             .arg(deltaH)
                             .arg(pow(10, logKp));

        // Показываем результаты пользователю
        QMessageBox::information(this, "Результаты", result);

        // Сохраняем результаты в файл
        QString fileName = QFileDialog::getSaveFileName(this, "Сохранить результаты", "", "Text Files (*.txt);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                QTextStream out(&file);
                out << result; // Записываем строку с результатами
                file.close();
                QMessageBox::information(this, "Успех", "Результаты успешно сохранены!");
            } else {
                QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи.");
            }
        }
    }
}



// Отрисовка фона
void MainWindow::drawBackground() {
    // Небо
    scene->addRect(0, 0, 800, 500, QPen(Qt::NoPen), QBrush{"#4C98CA"});

    // Трава
    scene->addRect(0, 420, 800, 350, QPen(Qt::NoPen), QBrush{"#80B929"});

    // Почва с камнями
    scene->addRect(0, 500, 800, 250, QPen(Qt::NoPen), QBrush{"#7E4811"});
    for (int i = 0; i < 100; ++i) {
        int x = QRandomGenerator::global()->bounded(0, 800);
        int y = QRandomGenerator::global()->bounded(500, 600);
        scene->addEllipse(x, y, 5, 5, QPen(Qt::NoPen), QBrush(Qt::darkGray));
    }
}

// Геттеры и сеттеры
void MainWindow::setValveOpen(bool open) { valveOpen = open; }
bool MainWindow::isValveOpen() const { return valveOpen; }

void MainWindow::setCatalystActive(bool active) { catalystActive = active; }
bool MainWindow::isCatalystActive() const { return catalystActive; }

void MainWindow::setReactionStarted(bool started) { reactionStarted = started; }
bool MainWindow::isReactionStarted() const { return reactionStarted; }

void MainWindow::setValveDisabled(bool disabled) { valveDisabled = disabled; }
bool MainWindow::isValveDisabled() const { return valveDisabled; }


void MainWindow::animateClouds() {
    for (auto *cloud : clouds) {
        // Двигаем облако вправо
        cloud->moveBy(2, 0); // Движение на 2 пикселя вправо

        // Если облако вышло за правую границу, перемещаем его налево
        if (cloud->x() > 600) {
            cloud->setX(-100); // Возвращаем облако на левую сторону
        }
    }
}
void MainWindow::mousePressEvent(QMouseEvent *event) {
    QPointF scenePos = centralWidget()->mapFromGlobal(event->globalPos());
    scenePos = static_cast<QGraphicsView*>(centralWidget())->mapToScene(scenePos.toPoint());

    // Проверяем нажатие на любую часть крана
    if (valveBase->contains(scenePos - valveBase->pos()) ||
        valveHandle->contains(scenePos - valveHandle->pos()) ||
        valveHandleTop->contains(scenePos - valveHandleTop->pos())) {
        toggleValve();
    }

    // Проверяем нажатие на катализатор
    if (catalyst->contains(scenePos - catalyst->pos())) {
        activateCatalyst();
    }
}

void MainWindow::updateMolecules() {
    if (!valveOpen) return;

    // Добавление новой молекулы, если кран открыт
    int y = QRandomGenerator::global()->bounded(480, 485); // Позиция в трубе
    auto *molecule = scene->addEllipse(90, y, 5, 5, QPen(Qt::black), QBrush(Qt::red));
    molecules.append(molecule);

    // Движение молекул
    for (auto *mol : molecules) {
        if (mol->x() < 200) {
            // Движение вправо по трубе
            mol->moveBy(5, 0);
        } else {
            // Если молекула в резервуаре, продолжаем двигать её там
            placeMoleculeInReservoir(mol);
        }
    }
}
void MainWindow::toggleValve() {
    if (valveDisabled) {
        QMessageBox::warning(this, "Кран заблокирован", "Кран уже был выключен и не может быть включён снова!");
        return; // Блокируем действие, если кран уже заблокирован
    }

    valveOpen = !valveOpen;
    QBrush brush = valveOpen ? QBrush(Qt::green) : QBrush(Qt::darkGray);

    valveBase->setBrush(brush);
    valveHandle->setBrush(brush);
    valveHandleTop->setBrush(brush);

    if (!valveOpen) {
        // Удаляем молекулы из трубы
        auto it = molecules.begin();
        while (it != molecules.end()) {
            QGraphicsEllipseItem *mol = *it;
            if (mol->x() < 300) { // Проверяем, находится ли молекула в трубе
                scene->removeItem(mol);
                it = molecules.erase(it);
                delete mol;
            } else {
                ++it;
            }
        }

        // Блокируем кран после выключения
        valveDisabled = true;
    }
}

void MainWindow::activateCatalyst() {
    catalystActive = true;
    catalyst->setBrush(Qt::red);
    startReaction();
}
void MainWindow::placeMoleculeInReservoir(QGraphicsEllipseItem *molecule) {
    static QVector<QPoint> freeCells;

    // Размеры молекулы
    int moleculeSize = 10; // Размер молекулы (диаметр)
    int cellSize = moleculeSize; // Размер ячейки равен размеру молекулы

    // Границы резервуара
    int reservoirLeft = 300;
    int reservoirTop = 100;
    int reservoirWidth = 200;
    int reservoirHeight = 400;

    // Количество строк и столбцов
    int rows = reservoirHeight / cellSize;
    int cols = reservoirWidth / cellSize;

    // Инициализация свободных ячеек
    if (freeCells.isEmpty()) {
        for (int y = 0; y < rows; ++y) {
            for (int x = 0; x < cols; ++x) {
                freeCells.append(QPoint(reservoirLeft + x * cellSize,
                                        reservoirTop + y * cellSize));
            }
        }
    }

    // Проверяем, остались ли свободные ячейки
    if (freeCells.isEmpty()) {
        return; // Все места заняты, не размещаем новую молекулу
    }

    // Берём случайную свободную ячейку
    int randomIndex = QRandomGenerator::global()->bounded(freeCells.size());
    QPoint position = freeCells[randomIndex];

    // Удаляем выбранную ячейку из списка
    freeCells.removeAt(randomIndex);

    // Устанавливаем молекулу в центр ячейки
    molecule->setRect(0, 0, moleculeSize, moleculeSize); // Устанавливаем размер молекулы
    molecule->setPos(position.x(), position.y());
}
void MainWindow::startReaction() {
    if (!catalystActive || reactionStarted) return;

    reactionStarted = true;

    // Удаляем молекулы из трубы
    auto it = molecules.begin();
    while (it != molecules.end()) {
        QGraphicsEllipseItem *mol = *it;
        if (mol->x() < 300) { // Молекула в трубе (до резервуара)
            scene->removeItem(mol);
            it = molecules.erase(it);
            delete mol;
        } else {
            ++it;
        }
    }

    // Добавляем молекулы в список для осаждения
    for (auto *mol : molecules) {
        settlingMolecules.append(mol);
    }

    // Запускаем таймер для анимации
    settlingTimer->start(50); // Обновление каждые 50 мс
}
void MainWindow::animateSettling() {
    if (settlingMolecules.isEmpty()) {
        settlingTimer->stop(); // Останавливаем таймер, если нечего анимировать
        return;
    }

    // Границы резервуара
    QRectF bounds = reservoir->rect();
    double bottomY = bounds.y() + bounds.height();

    for (int i = 0; i < settlingMolecules.size(); ++i) {
        auto *mol = settlingMolecules[i];

        // Проверяем, достигла ли молекула дна
        if (mol->y() + mol->boundingRect().height() < bottomY) {
            mol->moveBy(0, 5); // Перемещаем молекулу вниз на 5 пикселей
        } else {
            mol->setBrush(Qt::blue); // Меняем цвет на осадок
            settlingMolecules.remove(i);
            --i;
        }
    }
}
