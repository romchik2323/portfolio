#include "userinputdialog.h"
#include <QInputDialog>
#include <QMessageBox>
#include <QRegularExpression>

UserInputDialog::UserInputDialog(QObject *parent)
    : QObject(parent) {}

QString UserInputDialog::getUserName(const QSet<QString> &existingNames, QWidget *parent) {
    QString name;
    bool ok;

    do {
        name = QInputDialog::getText(parent, "Ввод имени пользователя",
                                     "Введите ваше имя:",
                                     QLineEdit::Normal, "", &ok);

        if (!ok) {
            emit userCanceled();
            return QString(); // Возвращаем пустую строку, если пользователь отменил ввод
        }

        QString validationError = validateUserName(name, existingNames);
        if (!validationError.isEmpty()) {
            QMessageBox::warning(parent, "Ошибка", validationError);
        } else {
            break;
        }
    } while (true);

    return name;
}

QString UserInputDialog::validateUserName(const QString &name, const QSet<QString> &existingNames) {
    if (name.isEmpty()) {
        return "Имя не может быть пустым!";
    }
    if (name.contains(QRegularExpression("[^a-zA-Zа-яА-Я0-9_ ]"))) {
        return "Имя содержит недопустимые символы!";
    }
    if (existingNames.contains(name)) {
        return "Это имя уже используется!";
    }
    return QString(); // Нет ошибок
}
