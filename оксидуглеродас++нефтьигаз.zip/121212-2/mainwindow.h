#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QGraphicsView>
#include <QRandomGenerator>
#include <QBrush>
#include <QPen>
#include <QInputDialog>
#include <QMessageBox>
#include <QComboBox>
#include <QFormLayout>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <cmath>
#include <QPushButton>
#include "modeselectiondialog.h"
#include "reactionparametersdialog.h"
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsEllipseItem>
#include <QTimer>
#include <QMouseEvent>
#include <QSet>
#include "userinputdialog.h"
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void mousePressEvent(QMouseEvent *event) override;

private slots:
    void updateMolecules();        // Обновление молекул
    void toggleValve();            // Переключение состояния крана
    void activateCatalyst();       // Активация катализатора
    void startReaction();          // Начало реакции
    void placeMoleculeInReservoir(QGraphicsEllipseItem *molecule); // Размещение молекулы

private:
    void requestUserName(); // Запрос имени пользователя
    UserInputDialog *userInputDialog;
    void setupScene();             // Инициализация сцены
    void drawBackground();         // Отрисовка фона       // Запрос имени пользователя
    void selectMode();             // Выбор режима
    void enterReactionParameters();// Ввод параметров реакции
    void animateSettling();        // Анимация осаждения
    void animateClouds();          // Анимация облаков

    // Поля
    QGraphicsScene *scene;
    QVector<QGraphicsEllipseItem *> clouds;
    QVector<QGraphicsEllipseItem *> molecules;
    QVector<QGraphicsEllipseItem *> settlingMolecules;

    QGraphicsRectItem *reservoir;
    QGraphicsRectItem *valveBase;
    QGraphicsRectItem *valveHandle;
    QGraphicsRectItem *valveHandleTop;
    QGraphicsRectItem *pipe;
    QGraphicsRectItem *catalyst;

    QTimer *moleculeTimer;
    QTimer *settlingTimer;
    QTimer *cloudTimer;

    QString userName;
    QSet<QString> existingNames;
    QString selectedMode;

    // Состояния
    bool valveOpen = false;
    bool catalystActive = false;
    bool reactionStarted = false;
    bool valveDisabled = false;

    // Геттеры и сеттеры
    void setValveOpen(bool open);
    bool isValveOpen() const;

    void setCatalystActive(bool active);
    bool isCatalystActive() const;

    void setReactionStarted(bool started);
    bool isReactionStarted() const;

    void setValveDisabled(bool disabled);
    bool isValveDisabled() const;
};

#endif // MAINWINDOW_H
