#ifndef REACTIONPARAMETERSDIALOG_H
#define REACTIONPARAMETERSDIALOG_H

#include <QDialog>
#include <QString>

class QLineEdit;

class ReactionParametersDialog : public QDialog {
    Q_OBJECT

public:
    explicit ReactionParametersDialog(QWidget *parent = nullptr);
    ~ReactionParametersDialog();

    double getTemperature() const; // Получение температуры
    double getPressure() const;    // Получение давления

private:
    QLineEdit *tempInput;          // Поле ввода температуры
    QLineEdit *pressureInput;      // Поле ввода давления
};

#endif // REACTIONPARAMETERSDIALOG_H
