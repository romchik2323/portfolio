#ifndef MODESELECTIONDIALOG_H
#define MODESELECTIONDIALOG_H

#include <QDialog>
#include <QString>
#include <QPushButton>

class ModeSelectionDialog : public QDialog {
    Q_OBJECT

public:
    explicit ModeSelectionDialog(QWidget *parent = nullptr);
    QString getSelectedMode() const;

private:
    QString selectedMode;
    QPushButton *basicModeButton;
    QPushButton *advancedModeButton;

private slots:
    void onBasicModeSelected();
    void onAdvancedModeSelected();
};

#endif // MODESELECTIONDIALOG_H
